jQuery(document).ready(function ($) {
	'use strict';

	$('.host-locally').on('click', function () {
		$(this).addClass('updating-message');
	});
});
